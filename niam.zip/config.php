<?php
$myweb = "http://www.nitbot.com/";
$myfacebook="http://facebook.com/niamtamami";
$mygithub="https://github.com/nitbot/";
$myyoutube="https://www.youtube.com/channel/UCcvaQtaNhx5G_OKXT6I3RAg";
$myblog="http://blog.nitbot.com/";
$myabout="http://niam.lecturer.pens.ac.id/";
$myemail="niam@pens.ac.id";
$mygmail="niamtamami@gmail.com";
$myrepo="http://repository.nitbot.com";
$myteachingmaterial = "http://teachingmaterial.nitbot.com";
$mycv = "http://mycv.nitbot.com";

$myPersonalDescrip="
<strong>Ni'am Tamami</strong> was born in Kediri, East Java, Indonesia in 1990. He received an S.ST. (Bachelor) degree in Applied Electronics Engineering from Politeknik Elektronika Negeri Surabaya (PENS) in 2012. He joined Politeknik Elektronika Negeri Surabaya (PENS) as lecturer in 2012. He received an M.T. (Master) degree in Applied Electronics Engineering from Politeknik Elektronika Negeri Surabaya (PENS) in 2014. He is now still active as D3 and D4 (3 and 4 years diploma) program lecturer, especially in Electronic Department. His teaching subjects are including (see my Teaching Material)
";

$myResearchTitle1="nitbot, it's me";
$myResearchDescrip1="Lecturer, Researcher ";

$myResearchTitle2="Internet Of Things | intel Galileo";
$myResearchDescrip2="send all data to internet";

$myResearchTitle3="nitbot UAV";
$myResearchDescrip3="unique UAV";

$myJournal = array();
$myJournal[1] = "Tamami, Niam, Endra Pitowarno, and I. Gede Puja Astawa. “A Combination of PD Controller and PIAFC for Stabilization of “x” Configuration Quadcopter.”, EMITTER International Journal of Engineering Technology, Vol 02, No. 01, 2014. ";
$myJournal[0] = "Tamami, Niam, Endra Pitowarno, and I. Gede Puja Astawa. “Proportional Derivative Active Force Control for “X” Configuration Quadcopter.”, Journal of Mechatronics, Electrical Power, and Vehicular Technology 5, no. 2 (2014): 67-74.";

$myPublication = array();
$myPublication[1] ="Tamami, Niam, Endra Pitowarno, and I. Gede Puja Astawa. “Modelling and PD Control for “x” Configuration Quadcopter”, Indonesian Symposium on Robot Soccer Competition 2013 – June 6th , 2013."; 
$myPublication[0] ="Bambang Sumantri, Ni’am Tamami, Nofria Hanafi, Mohamad Nasyir Tamara and Endra Pitowarno. “Rancang Bangun Aktuator Pada Prototype Picosatellite Menggunakan Sistem Magnetorquer.”, The 14th Industrial Electronics Seminar 2012 (IES 2012) Electronic Engineering Polytechnic Institute of Surabaya (EEPIS), Indonesia, October 24, 2012 : 22-27";

$researchArtikel = "My Research Focus is about smart device. Now I am doing some experiment to make smart home system and smart smart robotic home assistant. This years, my research still focus in Internet of Things device, see the web in http://iot.nitbot.com";

$miniArtikel1=array();
$miniArtikel1[0]="my Internet of Things";
$miniArtikel1[1]="Now, my product of internet of things is focused to make a internet control system. Make automation system that can used by many people who want to make their home fully controllable via internet. Very interesting, IoT not only for college, but also many people that dont have coding skill can use it in their home";
$miniArtikel1[2]= "http://iot.nitbot.com";

$miniArtikel2=array();
$miniArtikel2[0]="my Student";
$miniArtikel2[1]="Many research with my student, there are making electrocardiograph instrument, make a fuel monitoring system, and etc.";
$miniArtikel2[2]= "#";

$miniArtikel3=array();
$miniArtikel3[0]="my Experience";
$miniArtikel3[1]="Computer Networks, Sensor Actuator, Instrumentation, Intelligent Control System, Industrial Automation and Image Processing are my Teaching Experience in last 3 years. See my Curriculum Vitae?";
$miniArtikel3[2]= $mycv;

$miniArtikel4=array();
$miniArtikel4[0]="my Robot";
$miniArtikel4[1]="";
$miniArtikel4[2]= "#";


$miniArtikel5=array();
$miniArtikel5[0]="my Lab";
$miniArtikel5[1]="My Lab is AI Robotic Lab, AI is artificial intelligency. Many research of robotic here, Intelligent Robotic Arm, Intelligent Mobile Robot, Quadcopter, EDF Rocket and etc.";
$miniArtikel5[2]= "#";

$miniArtikel6=array();
$miniArtikel6[0]="my Activity";
$miniArtikel6[1]="Oke, silahkan cek agenda saya hari ini :)";
$miniArtikel6[2]= "#";

?>